$(function() {
	'use strict'

	const ps55 = new PerfectScrollbar('#mainContactList', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	const ps56 = new PerfectScrollbar('#mainContactList1', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
});